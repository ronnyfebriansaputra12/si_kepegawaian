<?php
    $query = mysqli_query($conn, "DELETE FROM unit WHERE id_unit = '".$_GET['id_unit']."'");
    if($query){
        echo "<script>alert('Data Berhasil Di Hapus')</script>";
        echo "<script>location = 'index.php?p=unit'</script>";
    }else{
        echo "<script>alert('Data Gagal Di Hapus')</script>";
    }

?>