<!DOCTYPE html>
<html lang="en">

<body>


    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table Nama Pendidikan</h6>
                <br>
                <a data-toggle="modal" data-target="#tambah_nm_pend" class="btn btn-primary">
                    Insert Data Nama Pendidikan
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Pendidikan</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>Nama Pendidikan</th>
                                <th>Option</th>
                            </tr>
                        </tfoot>
                        <tbody>

                        </tbody>

                        <?php

                        $query = mysqli_query($conn, "SELECT * FROM nama_pendidikan");
                        $cek = mysqli_num_rows($query);

                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $data['nama_pendidikan']; ?></td>
                                    <td>
                                    <a href="index.php?p=pendidikan_edit&nm_pendidikan=<?php echo $data['nm_pendidikan'] ?>" class="btn btn-success">Edit</a>
                                        <a href="index.php?p=pendidikan_hapus&nm_pendidikan=<?php echo $data['nm_pendidikan'] ?>" class="btn btn-danger" onclick="return confrim('Yakin Ingin Menghapus Data ?')">Hapus</a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>
                    <!-- Modal Tambah-->
                    <div class="modal fade" id="tambah_nm_pend" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Insert Data Nama Pendidikan</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="" method="POST">
                                        <div class="mb-3">
                                            <label style="text-align: center;" for="nama_pendidikan" class="form-label">Nama Tingkat Pendidikan</label>
                                            <input type="text" name="nama_pendidikan" class="form-control" id="nama_pendidikan" required>
                                        </div>
                                        <button style="float: right;" type="submit" class="btn btn-primary right" name="tambah">Tambah </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal Edit-->
                    <div class="modal fade" id="edit_unit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit Data Unit</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div id="unit_edit">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Query tambah Unit -->
    <?php

    if (isset($_POST['tambah'])) {
        $query = mysqli_query($conn, "INSERT INTO nama_pendidikan VALUES(NULL, '" . $_POST['nama_pendidikan'] . "')");

        if ($query) {
            echo "<script>alert('Data Berhasil DI Tambah')</script>";
            echo "<script>location='index.php?p=pendidikan'</script>";
        } else {
            echo "<script>alert('Data Gagal DI Tambah')</script>";
        }
    }


    ?>

    <!-- <script type="text/javascript">
        function dataId(a){
            $.ajax({
                type: 'post',
                url: 'unit_edit.php',
                data:{id_unit:a},
                success: function (response){
                    $('#unit_edit').html(response);
                } 
            });
        }
    </script> -->


</body>

</html>