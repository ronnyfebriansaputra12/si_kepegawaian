<div class="container-fluid">
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="card">
            <div class="card-header text-center">
                Insert Data Pegawai
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label for="nip" class="form-label">NIP</label>
                    <input type="text" name="nip" class="form-control" id="nip">
                </div>
                <div class="mb-3">
                    <label for="nama_pegawai" class="form-label">Nama Pegawai</label>
                    <input type="text" name="nama_pegawai" class="form-control" id="nama_pegawai">
                </div>
                <div class="input-group">
                    <input type="file" class="form-control" name="foto_pegawai" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                </div>
                <div class="mb-3">
                    <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" class="form-control" id="tempat_lahir">
                </div>
                <div class="mb-3">
                    <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control" id="tanggal_lahir">
                </div>
                <div class="form-group">
                    <label for="sel1">Jenis Kelamin</label>
                    <select class="form-control" name="jenis_kelamin">
                        <option value="">--Pilih Jenis Kelamin--</option>
                        <option value="laki-laki">Laki-Laki</option>
                        <option value="perempuan">Perempuan</option>
                    </select>
                </div>

                <div class="mb-3">
                <label for="sel1">Unit</label>

                    <select class="custom-select" aria-label="Default select example" name="id_unit">
                        <option disabled selected>-Pilih-</option>
                        <?php

                        $p = mysqli_query($conn, "SELECT * FROM unit");
                        while ($dpangkat = mysqli_fetch_array($p)) { ?>
                            <option value="<?php echo $dpangkat['id_unit'] ?>"><?php echo $dpangkat['nama_unit'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="sel1">Pilih Pangkat</label>
                    <select class="form-control" name="pangkat">
                        <option value="">--Pilih Pangkat--</option>
                        <?php

                        $pangkat = mysqli_query($conn, "SELECT * FROM pangkat");
                        while ($dpangkat = mysqli_fetch_array($pangkat)) { ?>
                        <option value="<?= $dpangkat['id_pangkat'] ?>"><?= $dpangkat['nama_pangkat']." - ".$dpangkat['jenis_pangkat'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="no_hp" class="form-label">Nomor Hp</label>
                    <input type="text" name="no_hp" class="form-control" id="no_hp">
                </div>
                <div class="form-group">
                    <label for="sel1">Agama</label>
                    <select class="form-control" name="agama">
                        <option value="">--Pilih Agama--</option>
                        <option value="Islam">Islam</option>
                        <option value="Kristen">Kristen</option>
                        <option value="Buddha">Buddha</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Konghucu">Konghucu</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" name="email" class="form-control" id="email">
                </div>
                <div class="form-floating">
                    <label for="alamat" class="form-label">Alamat</label>
                    <textarea class="form-control" name="alamat" placeholder="Alamat" id="floatingTextarea"></textarea>
                </div>
                <div class="form-group">
                    <label for="gol_darah">Golongan Darah</label>
                    <select class="form-control" name="gol_darah">
                        <option value="">--Pilih Golongan Darah--</option>
                        <option value="o">O</option>
                        <option value="a">A</option>
                        <option value="b">B</option>
                        <option value="ab">AB</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status_pernikahan">Status Pernikahan</label>
                    <select class="form-control" name="status_pernikahan">
                        <option value="">--Pilih Status Pernikahan--</option>
                        <option value="kawin">Kawin</option>
                        <option value="lajang">Lajang</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status_kepegawaian">Status Kepegawaian</label>
                    <select class="form-control" name="status_kepegawaian">
                        <option value="">--Pilih Status Kepegawaian--</option>
                        <option value="pns">PNS</option>
                        <option value="honor">Honor</option>
                    </select>
                </div>
                <br>
                <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
            </div>
        </div>
    </form>
</div>
<?php

if (isset($_POST['tambah'])) {
    $gambar = $_FILES['foto_pegawai']['name'];
    $temp = explode(".", $gambar);
    $newfilename = round(microtime(true)) . '.' . end($temp);
    $source = $_FILES['foto_pegawai']['tmp_name'];
    $folder = './../img/';
    

    if (move_uploaded_file($source,$folder.$newfilename)) {

        $nip = $_POST['nip'];
        $nama_pegawai = $_POST['nama_pegawai'];
        $foto_pegawai = $newfilename;
        $tempat_lahir = $_POST['tempat_lahir'];
        $tanggal_lahir = $_POST['tanggal_lahir'];
        $jenis_kelamin = $_POST['jenis_kelamin'];
        $id_unit = $_POST['id_unit'];
        $pangkat = $_POST['pangkat'];
        $no_hp = $_POST['no_hp'];
        $agama = $_POST['agama'];
        $email = $_POST['email'];
        $alamat = $_POST['alamat'];
        $gol_darah = $_POST['gol_darah'];
        $status_pernikahan = $_POST['status_pernikahan'];
        $status_kepegawaian = $_POST['status_kepegawaian'];

        $query = mysqli_query($conn,"INSERT INTO `pegawai` (`nip`, `nama_pegawai`, `foto_pegawai`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `id_unit`, `id_pangkat`, `no_hp`, `agama`, `email`, `alamat`, `gol_darah`, `status_pernikahan`, `status_kepegawaian`) VALUES ('$nip', '$nama_pegawai', '$foto_pegawai', '$tempat_lahir', '$tanggal_lahir', '$jenis_kelamin', '$id_unit', '$pangkat', '$no_hp', '$agama', '$email', '$alamat', '$gol_darah', '$status_pernikahan', '$status_kepegawaian')");
        if ($query) {
            echo "<script>alert('Data Berhasil DI Tambah')</script>";
            echo "<script>location='index.php?p=pegawai'</script>";
        }
        else{
            echo "gagal insert";
        }
    }
    else{
        echo "gagal";
    }
    
}


?>