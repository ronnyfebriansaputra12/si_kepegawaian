<!DOCTYPE html>
<html lang="en">

<body>


    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table Keluarga</h6>
                <br>
                <a data-toggle="modal" data-target="#tambah_keluarga" class="btn btn-primary">
                    Insert Data Unit
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIP</th>
                                <th>NIK</th>
                                <th>Nama Keluarga</th>
                                <th>Tempat Lahir</th>
                                <th>Tanggal Lahir</th>
                                <th>Pendidikan</th>
                                <th>Pekerjaan</th>
                                <th>Hubungan</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>NIP</th>
                                <th>NIK</th>
                                <th>Nama Keluarga</th>
                                <th>Tempat Lahir</th>
                                <th>Tanggal Lahir</th>
                                <th>Pendidikan</th>
                                <th>Pekerjaan</th>
                                <th>Hubungan</th>
                                <th>Option</th>
                            </tr>
                        </tfoot>
                        <tbody>

                        </tbody>

                        <?php

                        $query = mysqli_query($conn, "SELECT * FROM keluarga
                            INNER JOIN nama_pendidikan ON keluarga.nm_pendidikan = nama_pendidikan.nm_pendidikan
                            INNER JOIN pangkat ON keluarga.id_pangkat = pangkat.id_pangkat
                            INNER JOIN hubungan_kel ON keluarga.id_hubungan = hubungan_kel.id_hubungan

                            ");
                        $cek = mysqli_num_rows($query);

                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $data['nip']; ?></td>
                                    <td><?php echo $data['nik']; ?></td>
                                    <td><?php echo $data['nama_keluarga']; ?></td>
                                    <td><?php echo $data['tempat_lahir']; ?></td>
                                    <td><?php echo $data['tanggal_lahir']; ?></td>
                                    <td><?php echo $data['nm_pendidikan']; ?></td>
                                    <td><?php echo $data['pekerjaan']; ?></td>
                                    <td><?php echo $data['id_hubungan']; ?></td>
                                    <td>
                                        <a href="index.php?p=keluarga_edit&nik=<?php echo $data['nik'] ?>" class="btn btn-success">Edit</a>
                                        <a href="index.php?p=unit_hapus&nik=<?php echo $data['nik'] ?>" class="btn btn-danger" onclick="return confrim('Yakin Ingin Menghapus Data ?')">Hapus</a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>
                    <!-- Modal Tambah-->
                    <div class="modal fade" id="tambah_keluarga" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Insert Data keluarga</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="" method="POST">
                                        <div class="mb-3">
                                            <select class="custom-select" aria-label="Default select example" name="nip">
                                                <option selected disabled>Pilih Pegawai</option>
                                                <?php

                                                $nip = mysqli_query($conn, "SELECT * FROM pegawai");
                                                while ($dPegawai = mysqli_fetch_array($nip)) { ?>
                                                    <option value="<?php echo $dPegawai['nip'] ?>"><?php echo $dPegawai['nama_pegawai'] ?> <?php echo " - " ?> <?php echo $dPegawai['nip'] ?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="kepala_unit" class="form-label">NIK</label>
                                            <input type="text" name="nik" class="form-control" id="kepala_unit" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="nama_keluarga" class="form-label">Nama</label>
                                            <input type="text" name="nama_keluarga" class="form-control" id="nama_keluarga" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="tampat_lahir" class="form-label">Tempat Lahir</label>
                                            <input type="text" name="tempat_lahir" class="form-control" id="tampat_lahir" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="tanggal_lahir" class="form-label">Tempat Lahir</label>
                                            <input type="date" name="tanggal_lahir" class="form-control" id="tanggal_lahir" required>
                                        </div>
                                        <div class="mb-3">
                                            <select class="custom-select" aria-label="Default select example" name="nm_pendidikan">
                                                <option selected disabled>Tingkat Pendidikan</option>
                                                <?php

                                                $pend = mysqli_query($conn, "SELECT * FROM nama_pendidikan");
                                                while ($nm_pendidikan = mysqli_fetch_array($pend)) { ?>
                                                    <option value="<?php echo $nm_pendidikan['nm_pendidikan'] ?>"><?php echo $nm_pendidikan['nama_pendidikan'] ?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="pekerjaan" class="form-label">Pekerjaan</label>
                                            <input type="text" name="pekerjaan" class="form-control" id="pekerjaan" required>
                                        </div>
                                        <div class="mb-3">
                                            <select class="custom-select" aria-label="Default select example" name="id_hubungan">
                                                <option selected disabled>Hubungan Keluarga</option>
                                                <?php

                                                $hub_kel = mysqli_query($conn, "SELECT * FROM hubungan_kel");
                                                while ($hub_keluarga = mysqli_fetch_array($hub_kel)) { ?>
                                                    <option value="<?php echo $hub_keluarga['hub_keluarga'] ?>"><?php echo $hub_keluarga['nama_hubungan'] ?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <button style="float: right;" type="submit" class="btn btn-primary right" name="tambah">Tambah </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal Edit-->
                    <!-- <div class="modal fade" id="edit_unit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit Data Unit</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div id="unit_edit">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
    </div>

    <!-- Query tambah Unit -->
    <?php

    if (isset($_POST['tambah'])) {
        $query = mysqli_query($conn, "INSERT INTO keluarga VALUES(NULL, '" . $_POST['nip'] . "','" . $_POST['nik'] . "','" . $_POST['nama_keluarga'] . "','" . $_POST['tempat_lahir'] . "','" . $_POST['tanggal_lahir'] . "','" . $_POST['nm_pendidikan'] . "','" . $_POST['pekerjaan'] . "','" . $_POST['id_hubungan'] . "')");

        if ($query) {
            echo "<script>alert('Data Berhasil DI Tambah')</script>";
            echo "<script>location='index.php?p=keluarga'</script>";
        } else {
            echo "<script>alert('Data Gagal DI Tambah')</script>";
        }
    }


    ?>


</body>

</html>