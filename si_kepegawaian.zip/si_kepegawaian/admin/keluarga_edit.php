<?php 

        $query = mysqli_query($conn, "SELECT * FROM keluarga
        LEFT JOIN pegawai ON keluarga.nip = pegawai.nip
        LEFT JOIN hubungan_kel ON keluarga.id_hubungan = hubungan_kel.id_hubungan
        LEFT JOIN nama_pendidikan ON keluarga.nm_pendidikan = nama_pendidikan.nm_pendidikan
        WHERE nik = '" . $_GET['nik'] . "'
        ");
        $r = mysqli_fetch_array($query);

?>

<div class="container">
    <form class="" action="" method="POST">
        <div class="card">
            <div class="card-header text-center">
                <strong>Edit Data Keluarga</strong>
            </div>
            <div class="card-body">
                <!-- pegawai -->
                <div class="mb-3">
                    <select disabled class="custom-select" aria-label="Default select example" name="nip">
                        <option selected><?= $r['nama_pegawai'] ?><?= " - " ?><?php echo $r['nip'] ?></option>
                        <?php

                        $nip = mysqli_query($conn, "SELECT * FROM pegawai");
                        while ($dPegawai = mysqli_fetch_array($nip)) { ?>
                            <option value="<?php echo $dPegawai['nip'] ?>"><?php echo $dPegawai['nama_pegawai'] ?> <?php echo " - " ?> </option>
                        <?php
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="nik" class="form-label">NIK</label>
                    <input type="text" name="nik" class="form-control" id="nik" value="<?= $r['nik'] ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="nama_keluarga" class="form-label">Nama</label>
                    <input type="text" name="nama_keluarga" class="form-control" id="nama_keluarga" value="<?= $r['nama_keluarga'] ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" class="form-control" id="tempat_lahir" required placeholder="Example.. Padang" value="<?= $r['tempat_lahir'] ?>">
                </div>

                <div class="mb-3">
                    <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control" id="tanggal_lahir" required value="<?= $r['tanggal_lahir'] ?>">
                </div>

                                <!-- tingakt pendidikan -->
                <div class="mb-3">
                    <label for="nm_pendidikan" class="form-label">Tingkat Pendidikan</label>
                    <select class="custom-select" aria-label="Default select example" name="tingkat_pendidikan">
                        <?php

                        $pend = mysqli_query($conn, "SELECT * FROM nama_pendidikan");
                        while ($nama_pend = mysqli_fetch_array($pend)) { ?>
                            <option <?php if($r['nama_pendidikan']==$nama_pend['nm_pendidikan']){echo "selected "; } ?> value="<?php echo $nama_pend['nm_pendidikan'] ?>"><?php echo $nama_pend['nama_pendidikan'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="pekerjaan" class="form-label">Pekerjaan</label>
                    <input type="text" name="pekerjaan" class="form-control" id="pekerjaan" required value="<?= $r['pekerjaan'] ?>">
                </div>

                <div class="mb-3">
                    <label for="id_hubungan" class="form-label">Hubungan Keluarga</label>
                    <select class="custom-select" aria-label="Default select example" name="id_hubungan">
                        <option selected disabled>Pilih </option>
                        <?php

                        $hub = mysqli_query($conn, "SELECT * FROM hubungan_kel");
                        while ($Dhubungan = mysqli_fetch_array($hub)) { ?>
                            <option <?php if($r['id_hubungan']==$Dhubungan['id_hubungan']){echo "selected "; } ?> value="<?php echo $Dhubungan['id_hubungan'] ?>"><?php echo $Dhubungan['nama_hubungan'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>


                <button style="float: right;" type="submit" class="btn btn-primary right" name="edit">Update</button>
            </div>
        </div>
    </form>
</div>

<?php

if (isset($_POST['edit'])) {
    
    $query = mysqli_query($conn, "UPDATE keluarga SET nik = '" . $_POST['nik'] . "', nama_keluarga = '" . $_POST['nama_keluarga'] . "', tempat_lahir = '" . $_POST['tempat_lahir'] . "', tanggal_lahir = '" . $_POST['tanggal_lahir'] . "', nm_pendidikan = '" . $_POST['tingkat_pendidikan'] . "',pekerjaan = '" . $_POST['pekerjaan'] . "', id_hubungan = '" . $_POST['id_hubungan'] . "' WHERE nik ='" . $_GET['nik'] . "'");

    if ($query) {
        echo "<script>alert('Data Berhasil Di Update')</script>";
        echo "<script>location='index.php?p=keluarga'</script>";
    } else {
        echo "<script>alert('Data Gagal DI Update')</script>";
    }
}


?>