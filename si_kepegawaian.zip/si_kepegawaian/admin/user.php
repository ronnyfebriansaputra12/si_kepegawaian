<!DOCTYPE html>
<html lang="en">

<body>


    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table User</h6>
                <br>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Option</th>
                            </tr>
                        </tfoot>
                        <tbody>

                        </tbody>

                        <?php

                        $query = mysqli_query($conn, "SELECT * FROM user");
                        $cek = mysqli_num_rows($query);

                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $data['username']; ?></td>
                                    <td><?php echo $data['email']; ?></td>
                                    <td><?php echo $data['password']; ?></td>
                                    <td>
                                        <a href="index.php?p=user_edit&id_user=<?php echo $data['id_user'] ?>" class="btn btn-success">Edit</a>
                                        <a href="index.php?p=user_hapus&id_user=<?php echo $data['id_user'] ?>" class="btn btn-danger">Hapus</a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>

                </div>
            </div>
        </div>
    </div>
</body>

</html>