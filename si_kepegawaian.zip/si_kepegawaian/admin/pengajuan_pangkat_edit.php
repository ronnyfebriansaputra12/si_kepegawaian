<?php

$query = mysqli_query($conn, "SELECT * FROM pengajuan_pangkat
                                LEFT JOIN pegawai ON pengajuan_pangkat.nip = pegawai.nip
                                LEFT JOIN pangkat ON pengajuan_pangkat.id_pangkat = pangkat.id_pangkat
");
$r = mysqli_fetch_array($query);
?>

<div class="container-fluid">
<form action="" method="POST">
    <div class="card">
        <div class="card-header text-center">
            Edit Data Pengajuan Cuti
        </div>
        <div class="card-body">
            <div class="mb-3">
                    <select disabled class="custom-select" aria-label="Default select example" name="nip">
                        <option selected><?= $r['nama_pegawai'] ?><?= " - " ?><?php echo $r['nip'] ?></option>
                        <?php

                        $nip = mysqli_query($conn, "SELECT * FROM pegawai");
                        while ($dPegawai = mysqli_fetch_array($nip)) { ?>
                            <option value="<?php echo $dPegawai['nip'] ?>"><?php echo $dPegawai['nama_pegawai'] ?> <?php echo " - " ?> </option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
            <div class="mb-3">
            <select class="custom-select" aria-label="Default select example" name="id_pangkat">
                        <option selected><?= $r['nama_pangkat'] ?></option>
                        <?php

                        $p = mysqli_query($conn, "SELECT * FROM pangkat");
                        while ($dpangkat = mysqli_fetch_array($p)) { ?>
                            <option value="<?php echo $dpangkat['id_pangkat'] ?>"><?php echo $dpangkat['nama_pangkat'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
            </div>
            <div class="mb-3">
                <label for="tgl_pengajuan" class="form-label">Tanggal Pengjuan</label>
                <input type="date" name="tgl_pengajuan" class="form-control" id="tgl_pengajuan" value="<?php echo $r['tgl_pengajuan'] ?>" required>
            </div>
            <div class="form-group">
            <label for="sel1">Status:</label>
            <select class="form-control" name="status">
               <option value=""><?=$r['status'] ?></option>
               <option value="terima" <?php if($r['status']==1) { echo 'selected'; } ?>>Terima</option>
               <option value="tolak" <?php if($r['status']==2) { echo 'selected'; } ?>>Tolak</option>
            </select>
        </div>
            <br>
            <button style="float: right;" type="submit" name="edit" class="btn btn-primary">Edit</button>
        </div>
    </div>
</form>
</div>
<?php

if (isset($_POST['edit'])) {
    $query = mysqli_query($conn, "UPDATE pengajuan_pangkat SET id_pangkat='" . $_POST['id_pangkat'] . "',tgl_pengajuan='" . $_POST['tgl_pengajuan'] . "',status='" . $_POST['status'] . "' WHERE id_pengajuan = '" . $_GET['id_pengajuan'] . "' ");

    if ($query) {
        echo "<script>alert('Data Berhasil Di Edit')</script>";
        echo "<script>location = 'index.php?p=pengajuan_pangkat'</script>";
    } else {
        echo "<script>alert('Data Gagal Di Edit')</script>";
    }
}
?>