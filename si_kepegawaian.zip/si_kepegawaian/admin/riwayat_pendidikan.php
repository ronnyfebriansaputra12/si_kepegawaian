
    <div class="container">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table Riwayat Pendidikan</h6>
                <br>
                <a href="index.php?p=riwayat_pendidikan_tambah" class="btn btn-primary">Tambah</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIP</th>
                                <th>Nama Sekolah</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                        <?php

                        $query = mysqli_query($conn, "SELECT * FROM pendidikan
                                                    LEFT JOIN pegawai ON pendidikan.nip = pegawai.nip
                                                    LEFT JOIN nama_pendidikan ON pendidikan.nm_pendidikan = nama_pendidikan.nm_pendidikan
                        ");
                        $cek = mysqli_num_rows($query);

                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $data['nama_pegawai']; ?><?php echo" - " ?> <?php echo $data['nip']; ?></td>
                                    <td><?php echo $data['nama_sekolah']; ?></td>
                                    <td>
                                        <a href="index.php?p=riwayat_pendidikan_detail&id_pendidikan=<?php echo $data['id_pendidikan'] ?>" class="btn btn-info"><i class="fas fa-info-circle"></i></a>
                                        <a href="index.php?p=riwayat_pendidikan_edit&id_pendidikan=<?php echo $data['id_pendidikan'] ?>" class="btn btn-success"><i class="fas fa-user-edit"></i></a>
                                        <a href="index.php?p=riwayat_pendidikan_hapus&id_pendidikan=<?php echo $data['id_pendidikan'] ?>" class="btn btn-danger" onclick="return confrim('Yakin Ingin Menghapus Data ?')"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>
                </div>
            </div>
        </div>
    </div>