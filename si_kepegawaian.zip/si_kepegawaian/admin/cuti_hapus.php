<?php
    $query = mysqli_query($conn, "DELETE FROM pengajuan_cuti WHERE id_cuti = '".$_GET['id_cuti']."'");
    if($query){
        echo "<script>alert('Data Berhasil Di Hapus')</script>";
        echo "<script>location = 'index.php?p=cuti'</script>";
    }else{
        echo "<script>alert('Data Gagal Di Hapus')</script>";
    }

?>