<!DOCTYPE html>
<html lang="en">

<body>


    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table Unit</h6>
                <br>
                <a data-toggle="modal" data-target="#tambah_unit" class="btn btn-primary">
                    Insert Data Unit
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID-Unit</th>
                                <th>Nama Unit</th>
                                <th>Kepala Unit</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>ID-Unit</th>
                                <th>Nama Unit</th>
                                <th>Kepala Unit</th>
                                <th>Option</th>
                            </tr>
                        </tfoot>
                        <tbody>

                        </tbody>

                        <?php

                        $query = mysqli_query($conn, "SELECT * FROM unit");
                        $cek = mysqli_num_rows($query);

                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $data['id_unit']; ?></td>
                                    <td><?php echo $data['nama_unit']; ?></td>
                                    <td><?php echo $data['kepala_unit']; ?></td>
                                    <td>
                                    <a href="index.php?p=unit_edit&id_unit=<?php echo $data['id_unit'] ?>" class="btn btn-success">Edit</a>
                                        <a href="index.php?p=unit_hapus&id_unit=<?php echo $data['id_unit'] ?>" class="btn btn-danger" onclick="return confrim('Yakin Ingin Menghapus Data ?')">Hapus</a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>
                    <!-- Modal Tambah-->
                    <div class="modal fade" id="tambah_unit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Insert Data Unit</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="" method="POST">
                                        <div class="mb-3">
                                            <label style="text-align: center;" for="nama_unit" class="form-label">Nama Unit</label>
                                            <input type="text" name="nama_unit" class="form-control" id="nama_unit" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="kepala_unit" class="form-label">Kepala Unit</label>
                                            <input type="text" name="kepala_unit" class="form-control" id="kepala_unit" required>
                                        </div>
                                        <button style="float: right;" type="submit" class="btn btn-primary right" name="tambah">Tambah </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal Edit-->
                    <div class="modal fade" id="edit_unit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit Data Unit</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div id="unit_edit">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Query tambah Unit -->
    <?php

    if (isset($_POST['tambah'])) {
        $query = mysqli_query($conn, "INSERT INTO unit VALUES(NULL, '" . $_POST['nama_unit'] . "','" . $_POST['kepala_unit'] . "')");

        if ($query) {
            echo "<script>alert('Data Berhasil DI Tambah')</script>";
            echo "<script>location='index.php?p=unit'</script>";
        } else {
            echo "<script>alert('Data Gagal DI Tambah')</script>";
        }
    }


    ?>

    <!-- <script type="text/javascript">
        function dataId(a){
            $.ajax({
                type: 'post',
                url: 'unit_edit.php',
                data:{id_unit:a},
                success: function (response){
                    $('#unit_edit').html(response);
                } 
            });
        }
    </script> -->


</body>

</html>