<?php include '../conn/koneksi.php';
session_start();
if (!isset($_SESSION['username'])) {
    echo "<script>alert('Anda Harus Login')</script>";
    echo "<script>location='login.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Si Kepegawaian</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon">
          <i class="fas fa-user-tie"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Si Kepegawaian</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="index.php?p=dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          Dahsboard</a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Nav Item - Charts -->
      <li class="nav-item">
        <a class="nav-link" href="index.php?p=pegawai">
          <i class="fas fa-user-tie"></i>
          <span>Data Pegawai</span></a>
      </li>

      <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-fw fa-wrench"></i>
          <span>Data Riwayat</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="index.php?p=riwayat_pendidikan">Pendidikan</a>
            <a class="collapse-item" href="index.php?p=keluarga">Keluarga</a>
          </div>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-cog"></i>
          <span>Pengajuan</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Pengajuan Pegawai:</h6>
            <a class="collapse-item" href="index.php?p=cuti">Pengajuan Cuti</a>
            <a class="collapse-item" href="index.php?p=pengajuan_pangkat">Pengajuan Kenaikan Pangkat</a>
          </div>
        </div>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider">

      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#nav2" aria-expanded="true" aria-controls="nav2">
          <i class="fas fa-fw fa-cog"></i>
          <span>Data</span>
        </a>
        <div id="nav2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Data-Data:</h6>
            <a class="collapse-item" href="index.php?p=unit">Unit</a>
            <a class="collapse-item" href="index.php?p=pangkat">Pangkat</a>
            <a class="collapse-item" href="index.php?p=pendidikan">Pendidikan</a>
            <a class="collapse-item" href="index.php?p=hubungan">Hubungan Keluarga</a>
            <a class="collapse-item" href="index.php?p=user">user</a>
          </div>
        </div>
      </li>


      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
      <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>




            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= $_SESSION['username']; ?></span>
              </a>

              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="../index.php" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <?php
        if (@$_GET['p'] == "") {
          include_once 'dashboard.php';
        } elseif (@$_GET['p'] == "dashboard") {
          include_once 'dashboard.php';
        } elseif (@$_GET['p'] == "user") {
          include_once 'user.php';
        } elseif (@$_GET['p'] == "user_edit") {
          include_once 'user_edit.php';
        } elseif (@$_GET['p'] == "user_hapus") {
          include_once 'user_hapus.php';
        } elseif (@$_GET['p'] == "unit") {
          include_once 'unit.php';
        } elseif (@$_GET['p'] == "unit_tambah") {
          include_once 'unit_tambah.php';
        } elseif (@$_GET['p'] == "unit_edit") {
          include_once 'unit_edit.php';
        } elseif (@$_GET['p'] == "unit_hapus") {
          include_once 'unit_hapus.php';
        } elseif (@$_GET['p'] == "keluarga") {
          include_once 'keluarga.php';
        }elseif (@$_GET['p'] == "keluarga_detail") {
          include_once 'keluarga_detail.php';
        } 
        elseif (@$_GET['p'] == "keluarga_tambah") {
          include_once 'keluarga_tambah.php';
        } elseif (@$_GET['p'] == "keluarga_edit") {
          include_once 'keluarga_edit.php';
        } elseif (@$_GET['p'] == "keluarga_hapus") {
          include_once 'keluarga_hapus.php';
        } elseif (@$_GET['p'] == "unit_hapus") {
          include_once 'unit_hapus.php';
        } elseif (@$_GET['p'] == "pangkat") {
          include_once 'pangkat.php';
        } elseif (@$_GET['p'] == "pangkat_edit") {
          include_once 'pangkat_edit.php';
        } elseif (@$_GET['p'] == "pangkat_hapus") {
          include_once 'pangkat_hapus.php';
        } elseif (@$_GET['p'] == "pendidikan") {
          include_once 'pendidikan.php';
        } elseif (@$_GET['p'] == "pendidikan_edit") {
          include_once 'pendidikan_edit.php';
        } elseif (@$_GET['p'] == "pendidikan_hapus") {
          include_once 'pendidikan_hapus.php';
        }
        elseif (@$_GET['p'] == "riwayat_pendidikan") {
          include_once 'riwayat_pendidikan.php';
        }
        elseif (@$_GET['p'] == "riwayat_pendidikan_tambah") {
          include_once 'riwayat_pendidikan_tambah.php';
        }
        elseif (@$_GET['p'] == "riwayat_pendidikan_edit") {
          include_once 'riwayat_pendidikan_edit.php';
        }
        elseif (@$_GET['p'] == "riwayat_pendidikan_hapus") {
          include_once 'riwayat_pendidikan_hapus.php';
        }
        elseif (@$_GET['p'] == "riwayat_pendidikan_detail") {
          include_once 'riwayat_pendidikan_detail.php';
        }
        elseif (@$_GET['p'] == "jabatan") {
          include_once 'jabatan.php';
        }
        elseif (@$_GET['p'] == "jabatan_edit") {
          include_once 'jabatan_edit.php';
        }
        elseif (@$_GET['p'] == "jabatan_hapus") {
          include_once 'jabatan_hapus.php';
        }
        elseif (@$_GET['p'] == "jabatan_detail") {
          include_once 'jabatan_detail.php';
        }
        elseif (@$_GET['p'] == "hubungan") {
          include_once 'hubungan.php';
        }
        elseif (@$_GET['p'] == "hubungan_edit") {
          include_once 'hubungan_edit.php';
        }
        elseif (@$_GET['p'] == "hubungan_hapus") {
          include_once 'hubungan_hapus.php';
        }
        elseif (@$_GET['p'] == "cuti") {
          include_once 'cuti.php';
        }
        elseif (@$_GET['p'] == "cuti_edit") {
          include_once 'cuti_edit.php';
        }
        elseif (@$_GET['p'] == "cuti_hapus") {
          include_once 'cuti_hapus.php';
        }
        elseif (@$_GET['p'] == "pengajuan_pangkat") {
          include_once 'pengajuan_pangkat.php';
        }
        elseif (@$_GET['p'] == "pengajuan_pangkat_edit") {
          include_once 'pengajuan_pangkat_edit.php';
        }
        elseif (@$_GET['p'] == "pengajuan_pangkat_hapus") {
          include_once 'pengajuan_pangkat_hapus.php';
        }
        elseif (@$_GET['p'] == "pegawai") {
          include_once 'pegawai.php';
        }
        elseif (@$_GET['p'] == "pegawai_tambah") {
          include_once 'pegawai_tambah.php';
        }
        elseif (@$_GET['p'] == "pegawai_detail") {
          include_once 'pegawai_detail.php';
        }
        elseif (@$_GET['p'] == "pegawai_edit") {
          include_once 'pegawai_edit.php';
        }
        elseif (@$_GET['p'] == "pegawai_hapus") {
          include_once 'pegawai_hapus.php';
        }

        





        ?>
      </div>




      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Si Kepegawaian | By RonnyFebrianSaputra 2021</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Logout..?</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="../index.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>