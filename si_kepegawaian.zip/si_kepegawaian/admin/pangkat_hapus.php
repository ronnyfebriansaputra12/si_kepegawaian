<?php
    $query = mysqli_query($conn, "DELETE FROM pangkat WHERE id_pangkat = '".$_GET['id_pangkat']."'");
    if($query){
        echo "<script>alert('Data Berhasil Di Hapus')</script>";
        echo "<script>location = 'index.php?p=pangkat'</script>";
    }else{
        echo "<script>alert('Data Gagal Di Hapus')</script>";
    }

?>