<!DOCTYPE html>
<html lang="en">

<body>


    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table Jabatan</h6>
                <br>
                <a data-toggle="modal" data-target="#tambah_cuti" class="btn btn-primary">
                    Insert Data Cuti
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIP</th>
                                <th>Tanggal Pengajuan</th>
                                <th>Tanggal Masuk</th>
                                <th>Alasan</th>
                                <th>Status</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>

                        <?php

                        $query = mysqli_query($conn, "SELECT * FROM pengajuan_cuti
                                                    LEFT JOIN pegawai ON pengajuan_cuti.nip = pegawai.nip");
                        $cek = mysqli_num_rows($query);

                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $data['nama_pegawai']; ?><?= " - " ?><?= $data['nip'] ?></td>
                                    <td><?php echo $data['tgl_pengajuan']; ?></td>
                                    <td><?php echo $data['tgl_masuk']; ?></td>
                                    <td><?php echo $data['alasan']; ?></td>
                                    <td><?php echo $data['status']; ?></td>
                                    <td>
                                        <a href="index.php?p=cuti_detail&id_cuti=<?php echo $data['id_cuti'] ?>" class="btn btn-info"><i class="fas fa-info-circle"></i></a>
                                        <a href="index.php?p=cuti_edit&id_cuti=<?php echo $data['id_cuti'] ?>" class="btn btn-success"><i class="fas fa-user-edit"></i></a>
                                        <a href="index.php?p=cuti_hapus&id_cuti=<?php echo $data['id_cuti'] ?>" class="btn btn-danger" onclick="return confrim('Yakin Ingin Menghapus Data ?')"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>
                    <!-- Modal Tambah-->
                    <div class="modal fade" id="tambah_cuti" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Insert Data Unit</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="" method="POST">
                                        <div class="mb-3">
                                            <select class="custom-select" aria-label="Default select example" name="nip">
                                                <option selected disabled>Pilih Pegawai</option>
                                                <?php

                                                $Vnip = mysqli_query($conn, "SELECT * FROM pegawai");
                                                while ($dPegawai = mysqli_fetch_array($Vnip)) { ?>
                                                    <option value="<?php echo $dPegawai['nip'] ?>"><?php echo $dPegawai['nama_pegawai'] ?> <?php echo " - " ?> <?php echo $dPegawai['nip'] ?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label style="text-align: center;" for="tgl_pengajuan" class="form-label">Tanggal Pengajuan Cuti</label>
                                            <input type="date" name="tgl_pengajuan" class="form-control" id="tgl_pengajuan" required>
                                        </div>
                                        <div class="mb-3">
                                            <label style="text-align: center;" for="tgl_masuk" class="form-label">Tanggal Masuk</label>
                                            <input type="date" name="tgl_masuk" class="form-control" id="tgl_masuk" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="alasan" class="form-label">Alasan</label>
                                            <input type="text" name="alasan" class="form-control" id="alasan" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="sel1">Status:</label>
                                            <select class="form-control" name="status">
                                                <option value="">--Pilih Jenis Status--</option>
                                                <option value="terima">terima</option>
                                                <option value="tolak">Tolak</option>
                                            </select>
                                        </div>

                                        <button style="float: right;" type="submit" class="btn btn-primary right" name="tambah">Tambah </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Query tambah Unit -->
    <?php

    if (isset($_POST['tambah'])) {
        $query = mysqli_query($conn, "INSERT INTO pengajuan_cuti VALUES(NULL, '" . $_POST['nip'] . "','" . $_POST['tgl_pengajuan'] . "','" . $_POST['tgl_masuk'] . "','" . $_POST['alasan'] . "','" . $_POST['status'] . "')");

        if ($query) {
            echo "<script>alert('Data Berhasil DI Tambah')</script>";
            echo "<script>location='index.php?p=cuti'</script>";
        } else {
            echo "<script>alert('Data Gagal DI Tambah')</script>";
        }
    }


    ?>

    <!-- <script type="text/javascript">
        function dataId(a){
            $.ajax({
                type: 'post',
                url: 'unit_edit.php',
                data:{id_unit:a},
                success: function (response){
                    $('#unit_edit').html(response);
                } 
            });
        }
    </script> -->


</body>

</html>