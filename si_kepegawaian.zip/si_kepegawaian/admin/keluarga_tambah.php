<div class="container">
    <form class="" action="" method="POST">
        <div class="card">
            <div class="card-header text-center">
                <strong>Tambah Data Keluarga</strong>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <select class="custom-select" aria-label="Default select example" name="nip">
                        <option selected >Pilih Pegawai</option>
                        <?php

                        $Vnip = mysqli_query($conn, "SELECT * FROM pegawai");
                        while ($dPegawai = mysqli_fetch_array($Vnip)) { ?>
                            <option value="<?php echo $dPegawai['nip'] ?>"><?php echo $dPegawai['nama_pegawai'] ?> <?php echo " - " ?> <?php echo $dPegawai['nip'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="nik" class="form-label">NIK</label>
                    <input type="text" name="nik" class="form-control" id="nik" required>
                </div>
                <div class="mb-3">
                    <label for="nama_keluarga" class="form-label">Nama</label>
                    <input type="text" name="nama_keluarga" class="form-control" id="nama_keluarga" required>
                </div>
                <div class="mb-3">
                    <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" class="form-control" id="tempat_lahir" required>
                </div>
                <div class="mb-3">
                    <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control" id="tanggal_lahir" required>
                </div>
                <div class="mb-3">
                    <label for="tingkat_pend" class="form-label">Tingkat Pendidikan</label>
                    <select class="custom-select" aria-label="Default select example" name="nm_pendidikan">
                        <option selected disabled>Pilih Tingkat Pendidikan</option>
                        <?php

                        $pend = mysqli_query($conn, "SELECT * FROM nama_pendidikan");
                        while ($nama_pend = mysqli_fetch_array($pend)) { ?>
                            <option value="<?php echo $nama_pend['nm_pendidikan'] ?>"><?php echo $nama_pend['nama_pendidikan'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="pekerjaan" class="form-label">Perkejaan</label>
                    <input type="text" name="pekerjaan" class="form-control" id="pekerjaan" required>
                </div>                <div class="mb-3">
                    <label for="tingkat_pend" class="form-label">Hubungan Keluarga</label>
                    <select class="custom-select" aria-label="Default select example" name="id_hubungan">
                        <option selected disabled>Pilih Hubungan Keluarga</option>
                        <?php

                        $hub_kel = mysqli_query($conn, "SELECT * FROM hubungan_kel");
                        while ($hubungan = mysqli_fetch_array($hub_kel)) { ?>
                            <option value="<?php echo $hubungan['id_hubungan'] ?>"><?php echo $hubungan['nama_hubungan'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <button style="float: right;" type="submit" class="btn btn-primary right" name="tambah">Tambah </button>
            </div>
        </div>
    </form>
</div>

<?php

if (isset($_POST['tambah'])) {
    $query = mysqli_query($conn,"INSERT INTO keluarga VALUES('".$_POST['nik']."','".$_POST['nip']."','".$_POST['nama_keluarga']."','".$_POST['tempat_lahir']."','".$_POST['tanggal_lahir']."','".$_POST['nm_pendidikan']."','".$_POST['pekerjaan']."','".$_POST['id_hubungan']."')");

    // echo("Error description: " . mysqli_error($conn));
    // echo($query);
    if ($query) {
        echo "<script>alert('Data Berhasil DI Tambah')</script>";
        echo "<script>location='index.php?p=keluarga'</script>";
    } else {
        echo "<script>alert('Data Gagal DI Tambah')</script>";
    }
}


?>