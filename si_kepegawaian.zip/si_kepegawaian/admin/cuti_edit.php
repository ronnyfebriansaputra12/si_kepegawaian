<?php

$query = mysqli_query($conn, "SELECT * FROM pengajuan_cuti 
                                LEFT JOIN pegawai ON pengajuan_cuti.nip = pegawai.nip
                                WHERE id_cuti ='" . $_GET['id_cuti'] . "'  ");
$r = mysqli_fetch_array($query);
?>

<div class="container-fluid">
<form action="" method="POST">
    <div class="card">
        <div class="card-header text-center">
            Edit Data Pengajuan Cuti
        </div>
        <div class="card-body">
            <div class="mb-3">
                    <select disabled class="custom-select" aria-label="Default select example" name="nip">
                        <option selected><?= $r['nama_pegawai'] ?><?= " - " ?><?php echo $r['nip'] ?></option>
                        <?php

                        $nip = mysqli_query($conn, "SELECT * FROM pegawai");
                        while ($dPegawai = mysqli_fetch_array($nip)) { ?>
                            <option value="<?php echo $dPegawai['nip'] ?>"><?php echo $dPegawai['nama_pegawai'] ?> <?php echo " - " ?> </option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
            <div class="mb-3">
                <label for="tgl_pengajuan" class="form-label">Tanggal Pengajuan Cuti</label>
                <input type="date" name="tgl_pengajuan" class="form-control" id="tgl_pengajuan" value="<?php echo $r['tgl_pengajuan'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="tgl_masuk" class="form-label">Tanggal Masuk Kembali</label>
                <input type="date" name="tgl_masuk" class="form-control" id="tgl_masuk" value="<?php echo $r['tgl_masuk'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="alasan" class="form-label">alasan</label>
                <input type="text" name="alasan" class="form-control" id="alasan" value="<?php echo $r['alasan'] ?>" required>
            </div>
            <div class="form-group">
            <label for="sel1">Status:</label>
            <select class="form-control" name="status">
               <option value=""><?=$r['status'] ?></option>
               <option value="terima" <?php if($r['status']==1) { echo 'selected'; } ?>>Terima</option>
               <option value="tolak" <?php if($r['status']==2) { echo 'selected'; } ?>>Tolak</option>
            </select>
        </div>
            <br>
            <button style="float: right;" type="submit" name="edit" class="btn btn-primary">Edit</button>
        </div>
    </div>
</form>
</div>
<?php

if (isset($_POST['edit'])) {
    $query = mysqli_query($conn, "UPDATE pengajuan_cuti SET tgl_pengajuan='" . $_POST['tgl_pengajuan'] . "',tgl_masuk='" . $_POST['tgl_masuk'] . "',alasan='" . $_POST['alasan'] . "',status='" . $_POST['status'] . "' WHERE id_cuti = '" . $_GET['id_cuti'] . "' ");

    if ($query) {
        echo "<script>alert('Data Berhasil Di Edit')</script>";
        echo "<script>location = 'index.php?p=cuti'</script>";
    } else {
        echo "<script>alert('Data Gagal Di Edit')</script>";
    }
}
?>