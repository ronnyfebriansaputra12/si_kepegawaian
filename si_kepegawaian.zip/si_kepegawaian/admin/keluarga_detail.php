<div class="container">

    <h4 style="text-align: center;">Detail Riwayat Keluarga </h4>

    <?php

$query = mysqli_query($conn, "SELECT * FROM keluarga
        LEFT JOIN pegawai ON keluarga.nip = pegawai.nip
        LEFT JOIN hubungan_kel ON keluarga.id_hubungan = hubungan_kel.id_hubungan
        LEFT JOIN nama_pendidikan ON keluarga.nm_pendidikan = nama_pendidikan.nm_pendidikan
        WHERE nik = '".$_GET['nik']."'
");  
    while ($data = mysqli_fetch_array($query)) { ?>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <tr>
                            <td>NIP</td>
                            <td>:</td>
                            <td><?= $data['nama_pegawai'] ?><?= " - " ?><?= $data['nip'] ?></td>
                        </tr>
                        <tr>
                            <td>NIK</td>
                            <td>:</td>
                            <td><?= $data['nik'] ?></td>
                        </tr>
                        <tr>
                            <td>Nama Keluarga</td>
                            <td>:</td>
                            <td><?= $data['nama_keluarga'] ?></td>
                        </tr>
                        <tr>
                            <td>Tempat Lahir</td>
                            <td>:</td>
                            <td><?= $data['tempat_lahir'] ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Lahir</td>
                            <td>:</td>
                            <td><?= $data['tanggal_lahir'] ?></td>
                        </tr>
                        <tr>
                            <td>Pendidikan</td>
                            <td>:</td>
                            <td><?= $data['nama_pendidikan'] ?></td>
                        </tr>
                        <tr>
                            <td>Hubungan Keluarga</td>
                            <td>:</td>
                            <td><?= $data['nama_hubungan'] ?></td>
                        </tr>
                    </table>
                </div>



    <?php } ?>

    <a href="index.php?p=keluarga" class="btn btn-primary"><i class="fas fa-arrow-circle-left"></i></a>


</div>