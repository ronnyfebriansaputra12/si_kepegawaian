<div class="container">



    <h4 style="text-align: center;">Detail Data Pegawai </h4>

    <?php

    $query = mysqli_query($conn, "SELECT * FROM pegawai
INNER JOIN unit ON pegawai.id_unit = unit.id_unit 
INNER JOIN pangkat ON pegawai.id_pangkat = pangkat.id_pangkat 
WHERE pegawai.nip = '" . $_GET['nip'] . "'");
    while ($data = mysqli_fetch_array($query)) { ?>

        <div class="row">
            <div class="col-12 col-md-8">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tr>
                            <td>NIP</td>
                            <td>:</td>
                            <td><?= $data['nip'] ?></td>
                        </tr>
                        <tr>
                            <td>Tempat Lahir</td>
                            <td>:</td>
                            <td colspan="2"><?= $data['tempat_lahir'] ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Lahir</td>
                            <td>:</td>
                            <td colspan="2"><?= $data['tanggal_lahir'] ?></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td>:</td>
                            <td><?= $data['jenis_kelamin'] ?></td>
                        </tr>
                        <tr>
                            <td>Unit</td>
                            <td>:</td>
                            <td><?= $data['id_unit'] ?><?= "-" ?><?= $data['nama_unit'] ?></td>
                        </tr>
                        <tr>
                            <td>Pangkat</td>
                            <td>:</td>
                            <td><?= $data['nama_pangkat'] ?><?= "-" ?><?= $data['jenis_pangkat'] ?></td>
                        </tr>
                        <tr>
                            <td>Nomor HP</td>
                            <td>:</td>
                            <td><?= $data['no_hp'] ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>:</td>
                            <td><?= $data['email'] ?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?= $data['alamat'] ?></td>
                        </tr>
                        <tr>
                            <td>Golongan Darah</td>
                            <td>:</td>
                            <td><?= $data['gol_darah'] ?></td>
                        </tr>
                        <tr>
                            <td>Status Pernikahan</td>
                            <td>:</td>
                            <td><?= $data['status_pernikahan'] ?></td>
                        </tr>
                        <tr>
                            <td>status_kepegawaian</td>
                            <td>:</td>
                            <td><?= $data['status_kepegawaian'] ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <img src="<?= '../img/' . $data['foto_pegawai'] ?>" alt="">
            </div>
        </div>




    <?php } ?>

    <a href="index.php?p=keluarga" class="btn btn-primary"><i class="fas fa-arrow-circle-left"></i></a>


</div>