<?php

$query = mysqli_query($conn, "SELECT * FROM pangkat WHERE id_pangkat ='" . $_GET['id_pangkat'] . "'  ");
$r = mysqli_fetch_array($query);
?>

<div class="container-fluid">
<form action="" method="POST">
    <div class="card">
        <div class="card-header text-center">
            Edit Data Pangkat
        </div>
        <div class="card-body">
            <form>
            <form>
            <div class="mb-3">
                <label for="nama_pangkat" class="form-label">Nama Pangkat</label>
                <input type="text" name="nama_pangkat" class="form-control" id="nama_pangkat" value="<?php echo $r['nama_pangkat'] ?>" required>
            </div>
            <br>
            <button style="float: right;" type="submit" name="edit" class="btn btn-primary">Edit</button>
            </form>
            </form>
        </div>
    </div>
</form>
</div>

</div>

<?php

if (isset($_POST['edit'])) {
    $query = mysqli_query($conn, "UPDATE pangkat SET nama_pangkat = '" . $_POST['nama_pangkat'] . "' WHERE id_pangkat = '" . $_GET['id_pangkat'] . "' ");

    if ($query) {
        echo "<script>alert('Data Berhasil Di Edit')</script>";
        echo "<script>location = 'index.php?p=pangkat'</script>";
    } else {
        echo "<script>alert('Data Gagal Di Edit')</script>";
    }
}
?>
</div>