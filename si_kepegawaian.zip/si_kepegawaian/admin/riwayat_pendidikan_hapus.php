<?php
    $query = mysqli_query($conn, "DELETE FROM pendidikan WHERE id_pendidikan = '".$_GET['id_pendidikan']."'");
    if($query){
        echo "<script>alert('Data Berhasil Di Hapus')</script>";
        echo "<script>location = 'index.php?p=riwayat_pendidikan'</script>";
    }else{
        echo "<script>alert('Data Gagal Di Hapus')</script>";
    }

?>