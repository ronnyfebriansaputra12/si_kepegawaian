<!DOCTYPE html>
<html lang="en">

<body>


    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table Pegawai</h6>
                <br>
                <a href="index.php?p=pegawai_tambah" class="btn btn-primary">Tambah Data Pegawai</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIP</th>
                                <th>Nama Pegawai</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>

                        <?php

                        $query = mysqli_query($conn, "SELECT * FROM pegawai
                                                    LEFT JOIN unit ON pegawai.id_unit = unit.id_unit

                        ");



                        $cek = mysqli_num_rows($query);

                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) { ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $data['nip']; ?></td>
                            <td><?php echo $data['nama_pegawai']; ?></td>
                            <td>
                                        <a href="index.php?p=pegawai_detail&nip=<?php echo $data['nip'] ?>" class="btn btn-info"><i class="fas fa-info-circle"></i></a>
                                        <a href="index.php?p=pegawai_edit&nip=<?php echo $data['nip'] ?>" class="btn btn-success"><i class="fas fa-user-edit"></i></a>
                                        <a href="index.php?p=pegawai_hapus&nip=<?php echo $data['nip'] ?>" class="btn btn-danger" onclick="return confrim('Yakin Ingin Menghapus Data ?')"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                        </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>
                </div>
            </div>
        </div>
    </div>


</body>

</html>