<div class="container">

    <h4 style="text-align: center;">Detail Riwayat Pendidikan </h4>

    <?php

    $query = mysqli_query($conn, "SELECT * FROM pendidikan
                                                    LEFT JOIN pegawai ON pendidikan.nip = pegawai.nip
                                                    LEFT JOIN nama_pendidikan ON pendidikan.nm_pendidikan = nama_pendidikan.nm_pendidikan
                                                    WHERE id_pendidikan = '" . $_GET['id_pendidikan'] . "'
                        ");
    while ($data = mysqli_fetch_array($query)) { ?>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <tr>
                            <td>NIP</td>
                            <td>:</td>
                            <td><?= $data['nama_pegawai'] ?><?= " - " ?><?= $data['nip'] ?></td>
                        </tr>
                        <tr>
                            <td>Nama Sekolah</td>
                            <td>:</td>
                            <td><?= $data['nama_sekolah'] ?></td>
                        </tr>
                        <tr>
                            <td>Tingkat Pendidikan</td>
                            <td>:</td>
                            <td><?= $data['nama_pendidikan'] ?></td>
                        </tr>
                        <tr>
                            <td>Lokasi Universitas / Sekolah</td>
                            <td>:</td>
                            <td><?= $data['lokasi'] ?></td>
                        </tr>
                        <tr>
                            <td>Jurusan</td>
                            <td>:</td>
                            <td><?= $data['jurusan'] ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Ijazah</td>
                            <td>:</td>
                            <td><?= $data['tgl_ijazah'] ?></td>
                        </tr>
                        <tr>
                            <td>Nomor Ijazah</td>
                            <td>:</td>
                            <td><?= $data['no_ijazah'] ?></td>
                        </tr>
                    </table>
                </div>



    <?php } ?>

    <a href="index.php?p=riwayat_pendidikan" class="btn btn-primary"><i class="fas fa-arrow-circle-left"></i></a>


</div>