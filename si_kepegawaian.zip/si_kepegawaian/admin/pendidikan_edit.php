<?php

$query = mysqli_query($conn, "SELECT * FROM nama_pendidikan WHERE nm_pendidikan ='" . $_GET['nm_pendidikan'] . "'  ");
$r = mysqli_fetch_array($query);
?>

<div class="container-fluid">
<form action="" method="POST">
    <div class="card">
        <div class="card-header text-center">
            Edit Data Nama Pendidikan
        </div>
        <div class="card-body">
            <form>
            <form>
            <div class="mb-3">
                <label for="nama_unit" class="form-label">Nama Pendidikan</label>
                <input type="text" name="nama_pendidikan" class="form-control" id="nama_unit" value="<?php echo $r['nama_pendidikan'] ?>" required>
            </div>
            <br>
            <button style="float: right;" type="submit" name="edit" class="btn btn-primary">Edit</button>
            </form>
            </form>
        </div>
    </div>
</form>
</div>

</div>

<?php

if (isset($_POST['edit'])) {
    $query = mysqli_query($conn, "UPDATE nama_pendidikan SET nama_pendidikan = '" . $_POST['nama_pendidikan'] . "' WHERE nm_pendidikan = '" . $_GET['nm_pendidikan'] . "' ");

    if ($query) {
        echo "<script>alert('Data Berhasil Di Edit')</script>";
        echo "<script>location = 'index.php?p=pendidikan'</script>";
    } else {
        echo "<script>alert('Data Gagal Di Edit')</script>";
    }
}
?>
</div>