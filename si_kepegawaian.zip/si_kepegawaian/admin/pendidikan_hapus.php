<?php
    $query = mysqli_query($conn, "DELETE FROM nama_pendidikan WHERE nm_pendidikan = '".$_GET['nm_pendidikan']."'");
    if($query){
        echo "<script>alert('Data Berhasil Di Hapus')</script>";
        echo "<script>location = 'index.php?p=pendidikan'</script>";
    }else{
        echo "<script>alert('Data Gagal Di Hapus')</script>";
    }

?>