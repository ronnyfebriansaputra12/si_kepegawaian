<?php

$query = mysqli_query($conn, "SELECT * FROM pegawai
        LEFT JOIN unit ON pegawai.id_unit = unit.id_unit
        WHERE nip = '" . $_GET['nip'] . "'
        ");
$r = mysqli_fetch_array($query);

?>

    <div class="row">
        <div class="col-3">
            <div class="card" style="width: 16rem;">
                <img src="<?= '../img/'.$r['foto_pegawai'] ?>" class="card-img-top" alt="...">
            </div>
        </div>
        <div class="col-9">

            <form action="" method="POST" enctype="multipart/form-data">
                <div class="card">
                    <div class="card-header text-center">
                        Insert Data Pegawai
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="nip" class="form-label">NIP</label>
                            <input type="text" name="nip" class="form-control" id="nip" value="<?= $r['nip'] ?>">
                        </div>
                        <div class="mb-3">
                            <label for="nama_pegawai" class="form-label">Nama Pegawai</label>
                            <input type="text" name="nama_pegawai" class="form-control" id="nama_pegawai" value="<?= $r['nama_pegawai'] ?>">
                        </div>
                        <div class="input-group">
                            <input type="file" class="form-control" name="foto_pegawai" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                        </div>
                        <div class="mb-3">
                            <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
                            <input type="text" name="tempat_lahir" class="form-control" id="tempat_lahir" value="<?= $r['tempat_lahir'] ?>">
                        </div>
                        <div class="mb-3">
                            <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                            <input type="date" name="tanggal_lahir" class="form-control" id="tanggal_lahir" value="<?= $r['tanggal_lahir'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="sel1">Jenis Kelamin</label>
                            <select class="form-control" name="jenis_kelamin">
                                <option><?= $r['jenis_kelamin'] ?></option>
                                <option value="laki-laki" <?php if($r['jenis_kelamin']==1) { echo 'selected'; } ?>>Laki-Laki</option>
               <option value="perempuan" <?php if($r['jenis_kelamin']==2) { echo 'selected'; } ?>>Perempuan</option>
                            </select>
                        </div>

                        <div class="mb-3">
                    <label for="nm_pendidikan" class="form-label">Unit</label>
                    <select class="custom-select" aria-label="Default select example" name="id_unit">
                        <?php

                        $unit = mysqli_query($conn, "SELECT * FROM unit");
                        while ($Dunit = mysqli_fetch_array($unit)) { ?>
                            <option <?php if($r['id_unit']==$Dunit['id_unit']){echo "selected "; } ?> value="<?php echo $Dunit['id_unit'] ?>"><?php echo $Dunit['nama_unit'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>

                        <div class="mb-3">
                    <label for="nm_pendidikan" class="form-label">Pangkat</label>
                    <select class="custom-select" aria-label="Default select example" name="pangkat">
                        <?php

                        $pend = mysqli_query($conn, "SELECT * FROM pangkat");
                        while ($Dpangkat = mysqli_fetch_array($pend)) { ?>
                            <option <?php if($r['id_pangkat']==$Dpangkat['id_pangkat']){echo "selected "; } ?> value="<?php echo $Dpangkat['id_pangkat'] ?>"><?php echo $Dpangkat['nama_pangkat'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                        <div class="mb-3">
                            <label for="no_hp" class="form-label">Nomor Hp</label>
                            <input type="text" name="no_hp" class="form-control" id="no_hp" value="<?= $r['no_hp'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="sel1">Agama</label>
                            <select class="form-control" name="agama">
                                <option selected disabled>Pilih</option>
                                <option value="Islam" <?php if($r['agama']=="Islam") { echo 'selected'; } ?>>Islam</option>
                                <option value="Kristen" <?php if($r['agama']=="Kristen") { echo 'selected'; } ?>>Kristes</option>
                                <option value="Buddha" <?php if($r['agama']=="Buddha") { echo 'selected'; } ?>>Buddha</option>
                                <option value="Hindu" <?php if($r['agama']=="Hindu") { echo 'selected'; } ?>>Hindu</option>
                                <option value="Konghucu" <?php if($r['agama']=="Konghucu") { echo 'selected'; } ?>>Konghucu</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" name="email" class="form-control" id="email"value="<?= $r['email'] ?>">
                        </div>
                        <div class="form-floating">
                            <label for="alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" name="alamat" placeholder="Alamat" id="floatingTextarea"><?=$r['alamat'] ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="gol_darah">Golongan Darah</label>
                            <select class="form-control" name="gol_darah">
                                <option selected disabled>pilih</option>
                                <option value="o" <?php if($r['gol_darah']=="o") { echo 'selected'; } ?>>O</option>
                                <option value="a" <?php if($r['gol_darah']=="a") { echo 'selected'; } ?>>A</option>
                                <option value="b" <?php if($r['gol_darah']=="b") { echo 'selected'; } ?>>B</option>
                                <option value="ab" <?php if($r['gol_darah']=="ab") { echo 'selected'; } ?>>AB</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="status_pernikahan">Status Pernikahan</label>
                            <select class="form-control" name="status_pernikahan">
                                <option selected disabled>pilih</option>
                                <option value="kawin" <?php if($r['status_pernikahan']=="kawin") { echo 'selected'; } ?>>Kawin</option>
                                <option value="lajang"<?php if($r['status_pernikahan']=="lajang") { echo 'selected'; } ?>>Lajang</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="status_kepegawaian">Status Kepegawaian</label>
                            <select class="form-control" name="status_kepegawaian">
                                <option selected disabled>Pilih</option>
                                <option value="pns"<?php if($r['status_kepegawaian']=="pns") { echo 'selected'; } ?>>PNS</option>
                                <option value="honor"<?php if($r['status_kepegawaian']=="honor") { echo 'selected'; } ?>>Honor</option>
                            </select>
                        </div>
                        <br>
                        <button type="submit" name="edit" class="btn btn-primary float-right">Edit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php

if (isset($_POST['edit'])) {


    $cek = $_FILES['foto_pegawai']['name'];
    // echo "<pre>";
    // print_r($cek);
    // echo "</pre>";
    if ($cek != "") {

        $gambar = $_FILES['foto_pegawai']['name'];
        $temp = explode(".", $gambar);
        $newfilename = round(microtime(true)) . '.' . end($temp);
        $source = $_FILES['foto_pegawai']['tmp_name'];
        $folder = './../img/';
        
        

        if (move_uploaded_file($source,$folder.$newfilename)) {

            $nip = $_POST['nip'];
            $nama_pegawai = $_POST['nama_pegawai'];
            $foto_pegawai = $newfilename;
            $tempat_lahir = $_POST['tempat_lahir'];
            $tanggal_lahir = $_POST['tanggal_lahir'];
            $jenis_kelamin = $_POST['jenis_kelamin'];
            $id_unit = $_POST['id_unit'];
            $pangkat = $_POST['pangkat'];
            $no_hp = $_POST['no_hp'];
            $agama = $_POST['agama'];
            $email = $_POST['email'];
            $alamat = $_POST['alamat'];
            $gol_darah = $_POST['gol_darah'];
            $status_pernikahan = $_POST['status_pernikahan'];
            $status_kepegawaian = $_POST['status_kepegawaian'];

            $query = mysqli_query($conn,"UPDATE `pegawai` SET `nip` = '$nip', `nama_pegawai` = '$nama_pegawai',`foto_pegawai` = '$foto_pegawai', `tempat_lahir` = '$tempat_lahir', `tanggal_lahir` = '$tanggal_lahir', `jenis_kelamin` = '$jenis_kelamin', `id_unit` = '$id_unit', `id_pangkat` = '$pangkat', `no_hp` = '$no_hp', `agama` = '$agama', `email` = '$email', `alamat` = '$alamat', `gol_darah` = '$gol_darah', `status_pernikahan` = '$status_pernikahan', `status_kepegawaian` = '$status_kepegawaian' WHERE `pegawai`.`nip` = '".$_GET['nip']."'");
            if ($query) {
                unlink('../img/'.$r['foto_pegawai']);
                echo "<script>alert('Data Berhasil DI EDit')</script>";
                echo "<script>location='index.php?p=pegawai'</script>";
            }
            else{
                echo "gagal insert";
            }
        }
        else{
            echo "gagal";
        }
    }else{
        
        $nip = $_POST['nip'];
        $nama_pegawai = $_POST['nama_pegawai'];
        // $foto_pegawai = $newfilename;
        $tempat_lahir = $_POST['tempat_lahir'];
        $tanggal_lahir = $_POST['tanggal_lahir'];
        $jenis_kelamin = $_POST['jenis_kelamin'];
        $id_unit = $_POST['id_unit'];
        $pangkat = $_POST['pangkat'];
        $no_hp = $_POST['no_hp'];
        $agama = $_POST['agama'];
        $email = $_POST['email'];
        $alamat = $_POST['alamat'];
        $gol_darah = $_POST['gol_darah'];
        $status_pernikahan = $_POST['status_pernikahan'];
        $status_kepegawaian = $_POST['status_kepegawaian'];

        $query = mysqli_query($conn,"UPDATE `pegawai` SET `nip` = '$nip', `nama_pegawai` = '$nama_pegawai', `tempat_lahir` = '$tempat_lahir', `tanggal_lahir` = '$tanggal_lahir', `jenis_kelamin` = '$jenis_kelamin', `id_unit` = '$id_unit', `id_pangkat` = '$pangkat', `no_hp` = '$no_hp', `agama` = '$agama', `email` = '$email', `alamat` = '$alamat', `gol_darah` = '$gol_darah', `status_pernikahan` = '$status_pernikahan', `status_kepegawaian` = '$status_kepegawaian' WHERE `pegawai`.`nip` = '".$_GET['nip']."'");
        echo("Error description: " . mysqli_error($conn));
        if ($query) {
            echo "<script>alert('Data Berhasil DI EDit')</script>";
            echo "<script>location='index.php?p=pegawai'</script>";
        }
        else{
            echo "gagal edit";
        }
    }

    
}


?>