<?php
$query1 = mysqli_query($conn, "SELECT * FROM pegawai
LEFT JOIN unit ON pegawai.id_unit = unit.id_unit
WHERE nip = '" . $_GET['nip'] . "'
");

$r = mysqli_fetch_array($query1);
    $query = mysqli_query($conn, "DELETE FROM pegawai WHERE nip = '".$_GET['nip']."'");

    if($query){
        unlink('../img/'.$r['foto_pegawai']);
        echo "<script>alert('Data Berhasil Di Hapus')</script>";
        echo "<script>location = 'index.php?p=pegawai'</script>";
    }else{
        echo "<script>alert('Data Gagal Di Hapus')</script>";
    }

?>