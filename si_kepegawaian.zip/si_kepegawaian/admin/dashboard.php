<div class="container-fluid">
    <div class="row">

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <?php 
                                                        $query = mysqli_query($conn, "SELECT * FROM pegawai");
                                                        $jml = mysqli_num_rows($query);
                            
                            ?>
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Jumlah Pegawai</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$jml ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Annual) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                        <?php 
                                                        $query = mysqli_query($conn, "SELECT * FROM unit");
                                                        $jml_unit = mysqli_num_rows($query);
                            
                            ?>
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Jumlah Unit</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$jml_unit ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tasks Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <?php 
                            $query = mysqli_query($conn, "SELECT * FROM pengajuan_cuti");
                            $jml_pengajuan_cuti = mysqli_num_rows($query);
                            
                            ?>
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Pengajuan Cuti
                            </div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?=$jml_pengajuan_cuti ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pending Requests Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                        <?php 
                            $query = mysqli_query($conn, "SELECT * FROM pengajuan_cuti");
                            $jml_pengajuan_pangkat = mysqli_num_rows($query);
                            
                            ?>
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Pengajuan Pangkat</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $jml_pengajuan_pangkat ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-comments fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>