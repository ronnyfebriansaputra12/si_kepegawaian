<?php

$query = mysqli_query($conn, "SELECT * FROM unit WHERE id_unit ='" . $_GET['id_unit'] . "'  ");
$r = mysqli_fetch_array($query);
?>

<div class="container-fluid">
<form action="" method="POST">
    <div class="card">
        <div class="card-header text-center">
            Edit Data User
        </div>
        <div class="card-body">
            <form>
            <form>
            <div class="mb-3">
                <label for="nama_unit" class="form-label">Nama Unit</label>
                <input type="text" name="nama_unit" class="form-control" id="nama_unit" value="<?php echo $r['nama_unit'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="kepala_unit" class="form-label">kepala_unit</label>
                <input type="text" name="kepala_unit" class="form-control" id="kepala_unit" value="<?php echo $r['kepala_unit'] ?>" required>
            </div>
            <br>
            <button style="float: right;" type="submit" name="edit" class="btn btn-primary">Edit</button>
            </form>
            </form>
        </div>
    </div>
</form>
</div>

</div>

<?php

if (isset($_POST['edit'])) {
    $query = mysqli_query($conn, "UPDATE unit SET nama_unit = '" . $_POST['nama_unit'] . "',kepala_unit='" . $_POST['kepala_unit'] . "' WHERE id_unit = '" . $_GET['id_unit'] . "' ");

    if ($query) {
        echo "<script>alert('Data Berhasil Di Edit')</script>";
        echo "<script>location = 'index.php?p=unit'</script>";
    } else {
        echo "<script>alert('Data Gagal Di Edit')</script>";
    }
}
?>