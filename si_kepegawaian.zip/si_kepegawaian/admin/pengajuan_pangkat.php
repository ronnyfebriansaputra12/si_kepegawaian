
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table Pengajuan Kenaikan Pangkat</h6>
                <br>
                <a data-toggle="modal" data-target="#pengajuan_pangkat" class="btn btn-primary">
                    Insert Data Pengajuan Pangkat
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIP</th>
                                <th>Pangkat</th>
                                <th>Tanggal Pengajuan</th>
                                <th>Status</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>

                        <?php

                        $query = mysqli_query($conn, "SELECT * FROM pengajuan_pangkat
                                                    LEFT JOIN pegawai ON pengajuan_pangkat.nip = pegawai.nip
                                                    LEFT JOIN pangkat ON pengajuan_pangkat.id_pangkat = pangkat.id_pangkat
                                                    ");
                        $cek = mysqli_num_rows($query);

                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $data['nama_pegawai']; ?><?= " - " ?><?= $data['nip'] ?></td>
                                    <td><?php echo $data['nama_pangkat']; ?></td>
                                    <td><?php echo $data['tgl_pengajuan']; ?></td>
                                    <td><?php echo $data['status']; ?></td>
                                    <td>
                                        <a href="index.php?p=pengajuan_pangkat_detaik&id_pegajuan_p=<?php echo $data['id_pegajuan_p'] ?>" class="btn btn-info"><i class="fas fa-info-circle"></i></a>
                                        <a href="index.php?p=pengajuan_pangkat_edit&id_pegajuan_p=<?php echo $data['id_pegajuan_p'] ?>" class="btn btn-success"><i class="fas fa-user-edit"></i></a>
                                        <a href="index.php?p=pengajuan_pangkat_hapus&id_pegajuan_p=<?php echo $data['id_pegajuan_p'] ?>" class="btn btn-danger" onclick="return confrim('Yakin Ingin Menghapus Data ?')"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>
                    <!-- Modal Tambah-->
                    <div class="modal fade" id="pengajuan_pangkat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Insert Data Pengjuan Pangkat</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="" method="POST">
                                        <div class="mb-3">
                                            <select class="custom-select" aria-label="Default select example" name="nip">
                                                <option selected disabled>Pilih Pegawai</option>
                                                <?php

                                                $Vnip = mysqli_query($conn, "SELECT * FROM pegawai");
                                                while ($dPegawai = mysqli_fetch_array($Vnip)) { ?>
                                                    <option value="<?php echo $dPegawai['nip'] ?>"><?php echo $dPegawai['nama_pegawai'] ?> <?php echo " - " ?> <?php echo $dPegawai['nip'] ?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <select class="custom-select" aria-label="Default select example" name="id_pangkat">
                                                <option selected disabled>Pilih Pangkat</option>
                                                <?php

                                                $Vpangkat = mysqli_query($conn, "SELECT * FROM pangkat");
                                                while ($dPangkat = mysqli_fetch_array($Vpangkat)) { ?>
                                                    <option value="<?php echo $dPangkat['id_pangkat'] ?>"><?php echo $dPangkat['nama_pangkat'] ?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label style="text-align: center;" for="tgl_pengajuan" class="form-label">Tanggal Pengajuan</label>
                                            <input type="date" name="tgl_pengajuan" class="form-control" id="tgl_pengajuan" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="sel1">Status:</label>
                                            <select class="form-control" name="status">
                                                <option value="">--Pilih Jenis Status--</option>
                                                <option value="terima">terima</option>
                                                <option value="tolak">Tolak</option>
                                            </select>
                                        </div>

                                        <button style="float: right;" type="submit" class="btn btn-primary right" name="tambah">Pengajuan Cuti</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php

if (isset($_POST['tambah'])) {
    $query = mysqli_query($conn, "INSERT INTO pengajuan_pangkat VALUES(NULL, '" . $_POST['nip'] . "','" . $_POST['id_pangkat'] . "','" . $_POST['tgl_pengajuan'] . "','" . $_POST['status'] . "')");

    if ($query) {
        echo "<script>alert('Data Berhasil DI Tambah')</script>";
        echo "<script>location='index.php?p=pengajuan_pangkat'</script>";
    } else {
        echo "<script>alert('Data Gagal DI Tambah')</script>";
    }
}


?>