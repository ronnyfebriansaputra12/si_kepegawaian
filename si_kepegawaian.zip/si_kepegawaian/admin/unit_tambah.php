<div class="container-fluid">
    <form action="" method="POST">
        <div class="card">
            <div class="card-header text-center">
                Insert Data Unit
            </div>
            <div class="card-body">
                <form>
                    <div class="mb-3">
                        <label for="nama_unit" class="form-label">Nama Unit</label>
                        <input type="text" name="nama_unit" class="form-control" id="nama_unit" required>
                    </div>
                    <div class="mb-3">
                        <label for="kepala_unit" class="form-label">Kepala Unit</label>
                        <input type="text" name="kepala_unit" class="form-control" id="kepala_unit" required>
                    </div>
                    <br>
                    <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
                </form>
            </div>
        </div>
    </form>
</div>
<?php

if (isset($_POST['tambah'])) {
    $query = mysqli_query($conn, "INSERT INTO unit VALUES(NULL, '" . $_POST['nama_unit'] . "','" . $_POST['kepala_unit'] . "')");

    if ($query) {
        echo "<script>alert('Data Berhasil DI Tambah')</script>";
        echo "<script>location='index.php?p=unit'</script>";
    } else {
        echo "<script>alert('Data Gagal DI Tambah')</script>";
    }
}


?>