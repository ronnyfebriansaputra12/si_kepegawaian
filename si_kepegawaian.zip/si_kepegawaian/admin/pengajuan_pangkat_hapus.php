<?php
    $query = mysqli_query($conn, "DELETE FROM pengajuan_pangkat WHERE id_pegajuan_p = '".$_GET['id_pegajuan_p']."'");
    if($query){
        echo "<script>alert('Data Berhasil Di Hapus')</script>";
        echo "<script>location = 'index.php?p=pengajuan_pangkat'</script>";
    }else{
        echo "<script>alert('Data Gagal Di Hapus')</script>";
    }

?>