<!DOCTYPE html>
<html lang="en">

<body>


    

    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table Keluarga</h6>
                <br>
                <a href="index.php?p=keluarga_tambah" class="btn btn-primary">Tambah</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nip</th>
                                <th>NIK</th>
                                <th>Nama</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>

                        <?php

                        $query = mysqli_query($conn, "SELECT * FROM keluarga
                                                    INNER JOIN pegawai ON keluarga.nip = pegawai.nip
                                                    INNER JOIN hubungan_kel ON keluarga.id_hubungan = hubungan_kel.id_hubungan
                                                    INNER JOIN nama_pendidikan ON keluarga.nm_pendidikan = nama_pendidikan.nm_pendidikan
                        ");

//                         echo '<pre>';
// print_r(mysqli_fetch_assoc($query));
// echo '</pre>';
// die;
                        $cek = mysqli_num_rows($query);


                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $data['nama_pegawai']; ?><?php echo" - " ?> <?php echo $data['nip']; ?></td>
                                    <td><?php echo $data['nik'] ?></td>
                                    <td><?php echo $data['nama_keluarga']; ?></td>
                                    <td>
                                        <a href="index.php?p=keluarga_detail&nik=<?php echo $data['nik'] ?>" class="btn btn-info"><i class="fas fa-info-circle"></i></a>
                                        <a href="index.php?p=keluarga_edit&nik=<?php echo $data['nik'] ?>" class="btn btn-success"><i class="fas fa-user-edit"></i></a>
                                        <a href="index.php?p=keluarga_hapus&nik=<?php echo $data['nik'] ?>" class="btn btn-danger" onclick="return confrim('Yakin Ingin Menghapus Data ?')"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>
                </div>
            </div>
        </div>
    </div>



</body>

</html>