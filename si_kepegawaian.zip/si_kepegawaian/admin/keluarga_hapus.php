<?php
    $query = mysqli_query($conn, "DELETE FROM keluarga WHERE nik = '".$_GET['nik']."'");
    if($query){
        echo "<script>alert('Data Berhasil Di Hapus')</script>";
        echo "<script>location = 'index.php?p=keluarga'</script>";
    }else{
        echo "<script>alert('Data Gagal Di Hapus')</script>";
    }

?>