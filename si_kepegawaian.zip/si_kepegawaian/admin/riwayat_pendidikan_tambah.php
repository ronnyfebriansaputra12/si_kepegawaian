<div class="container">
    <form class="" action="" method="POST">
        <div class="card">
            <div class="card-header text-center">
                <strong>Tambah Data Riwayat Pendidikan</strong>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <select class="custom-select" aria-label="Default select example" name="nip">
                        <option selected disabled>Pilih Pegawai</option>
                        <?php

                        $nip = mysqli_query($conn, "SELECT * FROM pegawai");
                        while ($dPegawai = mysqli_fetch_array($nip)) { ?>
                            <option value="<?php echo $dPegawai['nip'] ?>"><?php echo $dPegawai['nama_pegawai'] ?> <?php echo " - " ?> <?php echo $dPegawai['nip'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="nama_sekolah" class="form-label">Nama Universitas</label>
                    <input type="text" name="nama_sekolah" class="form-control" id="nama_sekolah" required>
                </div>
                <div class="mb-3">
                    <label for="tingkat_pend" class="form-label">Tingkat Pendidikan</label>
                    <select class="custom-select" aria-label="Default select example" name="nm_pendidikan">
                        <option selected disabled>Pilih Tingkat Pendidikan</option>
                        <?php

                        $pend = mysqli_query($conn, "SELECT * FROM nama_pendidikan");
                        while ($nama_pend = mysqli_fetch_array($pend)) { ?>
                            <option value="<?php echo $nama_pend['nm_pendidikan'] ?>"><?php echo $nama_pend['nama_pendidikan'] ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="lokasi" class="form-label">Lokasi</label>
                    <input type="text" name="lokasi" class="form-control" id="lokasi" required placeholder="Example.. Padang">
                </div>
                <div class="mb-3">
                    <label for="jurusan" class="form-label">Jurusan</label>
                    <input type="text" name="jurusan" class="form-control" id="jurusan" required>
                </div>
                <div class="mb-3">
                    <label for="tgl_ijazah" class="form-label">Tanggal Ijazah</label>
                    <input type="date" name="tgl_ijazah" class="form-control" id="tgl_ijazah" required>
                </div>
                <div class="mb-3">
                    <label for="no_ijazah" class="form-label">Nomor Ijazah</label>
                    <input type="text" name="no_ijazah" class="form-control" id="no_ijazah" required>
                </div>
                <button style="float: right;" type="submit" class="btn btn-primary right" name="tambah">Tambah </button>
            </div>
        </div>
    </form>
</div>

<?php

if (isset($_POST['tambah'])) {
    $query = mysqli_query($conn, "INSERT INTO pendidikan VALUES(NULL, '" . $_POST['nip'] . "','" . $_POST['nama_sekolah'] . "','" . $_POST['nm_pendidikan'] . "','" . $_POST['lokasi'] . "','" . $_POST['jurusan'] . "','" . $_POST['tgl_ijazah'] . "','" . $_POST['no_ijazah'] . "')");

    if ($query) {
        echo "<script>alert('Data Berhasil DI Tambah')</script>";
        echo "<script>location='index.php?p=riwayat_pendidikan'</script>";
    } else {
        echo "<script>alert('Data Gagal DI Tambah')</script>";
    }
}


?>